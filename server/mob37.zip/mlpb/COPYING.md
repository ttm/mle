LICENSE
=======

MOb is a free software and non-commercial use only: you can be use it for creating unlimited applications, distribute in binary or object form only, modify source-code and distribute modifications (derivative works). Please, giving credit to the author by citing the papers. License will expire in 2018, July, and will be renewed.

Owner or contributors are not liable for any direct, indirect, incidental, special, exemplary, or consequential damages, (such as loss of data or profits, and others) arising in any way out of the use of this software, even if advised of the possibility
of such damage.
